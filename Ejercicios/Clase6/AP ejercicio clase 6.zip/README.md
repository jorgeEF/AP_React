# Ejercicio

Desarrollar el registro de una página web, en el registro tener los siguientes campos:  
- Nombre
- Apellido
- Email
- Teléfono
- Password
- Confirmarpassword
  
Realizar solo el maquetado utilizando reactjs y JSX, no se deben guardar los usuarios ni realizar lógica de validación de los mismos
